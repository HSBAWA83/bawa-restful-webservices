package com.bawa.rest.webservices.bawarestfulwebservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BawaRestfulWebservicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
