package com.bawa.rest.webservices.bawarestfulwebservices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BawaRestfulWebservicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(BawaRestfulWebservicesApplication.class, args);
	}

}
